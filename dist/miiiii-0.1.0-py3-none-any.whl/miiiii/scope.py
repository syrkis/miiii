# scope
#   neuralnetscopy codebase
# by: Noah Syrkis

# imports
import jax
from jax import random, grad, jit, value_and_grad
import optax


# functions


# main
if __name__ == "__main__":
    print("neuralnetscopy device")
